Config = {}

Config.blipsShow = true

Config.Locations = {
[1] = {
    vector = vector3(-602.87, -929.53, 23.86), 
    text = "Weazel News", 
    color = 1, 
    sprite = 590, 
    scale = 0.5,
},
-- Example 
-- [[
-- [2] = {
--     vector = vector3(0, 0, 0),
--     text = "Blip Name", 
--     color = 3, 
--     sprite = Blip ID, 
--     scale = size,
-- }, ]]

--- add more
}
