fx_version 'cerulean'
game 'gta5'


author 'CD-Development'
description 'Easy to Create Blips [Standalone]'
version '1.0'
discord 'https://discord.gg/E2gq4WSz2j'
scriptname 'cd-blips'



shared_script 'config.lua'
client_script 'server/main.lua'

lua54 'yes'
